Jeux labyrinthe 
1- ouvrir un fenetre Dos
2- positionnez vous le répertoire ou vous avez desipper le fichier labyrinthe.zip
3- exécutez le fichier roboc.py (python roboc.py)
4- jouez !!! 	
