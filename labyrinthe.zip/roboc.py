﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Ce fichier contient le code principal du jeu.

Exécutez-le avec Python pour lancer le jeu.

"""

import os
import re
import sys
from carte import Carte
import pickle

def lanceRoboc():
    
    """ 
    Emplacement pré définie des cartes. 
    """

    ListMaps={}
    i=0
    PathMaps="./cartes"
    dirs = os.listdir(PathMaps)
    for file in dirs:
        if file.endswith(".txt"):
            i+=1
            ListMaps[i]= file
           

    print("Parmis les cartes disponibles ci-dessous ")
    print("N° de la carte - nom de la carte")
    for idCarte, nomCarte in ListMaps.items():
	    print("{} - {}".format(idCarte, nomCarte))


    idCarteSelect = '0'    
    
    while True: 
        mon_codage = ("veuillez sélectionner votre N° de la carte  ou taper Q pour sortir : ")
        idCarteSelect = input(mon_codage)
        if idCarteSelect.upper() == 'Q':
            print("Fermeture du jeux")
            break
        try:
            if int(idCarteSelect) in ListMaps.keys():
                print("Vous avez choisi la carte {}".format(ListMaps[int(idCarteSelect)]))
                if os.path.exists("sauvegardePartieCarte-"+idCarteSelect) :
                    with open("sauvegardePartieCarte-"+idCarteSelect, "rb") as fichier:
                        mon_depickler = pickle.Unpickler(fichier)
                        jeux = mon_depickler.load()
                    fichier.close()
                else: 
                    jeux=Carte(idCarteSelect,ListMaps[int(idCarteSelect)])
                    jeux.readCarte()
                jeuxInitial=Carte(idCarteSelect,ListMaps[int(idCarteSelect)])
                jeuxInitial.readCarte()
                jeux.afficheCarte(jeuxInitial)
            while True:
                mv = input("Entrer un déplacement : ")
                regexp = re.compile(r'[OENSQoensq]')
                if regexp.search(mv[0])==None:
                    print("Vous devez entrer en 1ère lettre, une des lettres O ou E ou N ou S ou Q!!!")

                    #on quitte le jeux
                elif mv[0].upper() == 'Q':
                    print("Fermeture du jeux")
                    os._exit(1)

                elif mv[1:].isdigit()==False:
                    print("Vous devez entrer après la lettre un nombre")
                else :   
                    jeux.deplaceJoueur(jeuxInitial,mv)
                    jeux.afficheCarte(jeuxInitial)
                    
                    # Sauvegarde du jeux 
                    with open("sauvegardePartieCarte-"+idCarteSelect, "wb") as savedFile:
                        pickler = pickle.Pickler(savedFile)
                        pickler.dump(jeux)
                    savedFile.close()

            else:
                print("Merci d'entrer un n° entre 1 et {}".format(len(ListMaps.keys())))
        except:
            print("Ce jeux n'autorise que les caractères : Q pour sortir ... et les n° des cartes ...")



lanceRoboc()

